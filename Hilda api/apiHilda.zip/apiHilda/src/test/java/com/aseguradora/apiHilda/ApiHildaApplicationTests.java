package com.aseguradora.apiHilda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiHildaApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.aseguradora.apiHilda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiHildaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiHildaApplication.class, args);
	}

}
